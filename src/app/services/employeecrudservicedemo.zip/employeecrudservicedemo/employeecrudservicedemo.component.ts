import { Component, OnInit } from '@angular/core';
import { Employee } from './Employee';
import { EmployeeserviceService } from './employeeservice.service';

@Component({
  selector: 'app-employeecrudservicedemo',
  templateUrl: './employeecrudservicedemo.component.html',
  styleUrls: ['./employeecrudservicedemo.component.css'],
  providers: [EmployeeserviceService],
})
export class EmployeecrudservicedemoComponent implements OnInit {
  value:any;
  // employee:Employee={
  //     eid:"",
  //     firstname: '',
  //     lastname: '',
  //     department:'',
  //     salary:0,
  //   };
  
  constructor(private empData:EmployeeserviceService) {
    
  }

  ngOnInit(): void {}

  addEmployee=(formValue:any)=>{
    this.value=formValue;
    this.empData.addEmployee(formValue)
    console.log(this.empData.employeeData)
  }
}
