export class Employee {
    eid:string="";
    firstname: string = '';
    lastname: string = '';
    salary:number=0;
    department:string="";
  }
  