import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {

   eid:string="";
     firstname:string="";
     lastname:string="";
     department:string="";
     salary:number=0
  constructor() {}
   public employeeData:any=[{
    
   }];

   isEdited:boolean=false;
   isSelectedIndex:number=0;
  public addEmployee=(emp:any):void=>{
    console.log("in service")
    this.employeeData.push(emp);
    console.log(this.employeeData)
  }

  public removeEmployee=(i:number)=>{
    this.employeeData.splice(i,1);
  }
  
  public editEmployee=(i:number)=>{
    this.isEdited=true;
    this.isSelectedIndex=i;
    
  }

}
